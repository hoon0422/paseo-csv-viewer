# CSV Viewer

CSV Viewer lets you inspect an existing UTF-8 CSV or TSV in a read-only Paseo workspace panel. Open it from the Command Center or workspace header, then enter a workspace path, choose a local file, or drop one from Paseo Files or the desktop file manager.

The panel shows an early preview, then prepares the complete file for paging, full-file search, text or exact numeric sorting, and copying visible cells or selected rows. The first record is a header by default and can be treated as data instead. A source change leaves the completed snapshot visible with a notice; Refresh reads the changed file.

The tested environment is the official Paseo 0.12.0 desktop and daemon on Ubuntu 24.04.5 x86_64. macOS and Windows desktop behavior has not yet been verified in isolated environments. The app and daemon must both run the supported Paseo version. External drops and the local picker require the desktop's own running daemon to be the selected host. The default `csv-viewer` plugin ID is required for native DuckDB loading in Paseo 0.12.0. Node and npm are needed on the daemon for the locked runtime preparation step.

The daemon reads the source file at its existing path; external drops do not upload or copy the whole file. It uses temporary disk for a DuckDB database, WAL, and possible sort spill, then removes its owned storage on close or replacement. CSV Viewer does not modify the original file. As a trusted Paseo plugin, its server code has the daemon user's access to local files, processes, credentials, and network services. Paseo Files drag data, the desktop local-file bridge, and the native loader path depend on internal Paseo 0.12.0 behavior, so compatibility with later releases is unverified.
